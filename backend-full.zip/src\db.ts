import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

export const pool = mysql.createPool({
  host: process.env.DB_HOST || process.env.PGHOST || 'localhost',
  user: process.env.DB_USER || process.env.PGUSER || 'gymtragh_bingo',
  password: process.env.DB_PASS || process.env.PGPASSWORD || '',
  database: process.env.DB_NAME || process.env.PGDATABASE || 'gymtragh_bingo',
  port: parseInt(process.env.DB_PORT || process.env.PGPORT || '3306', 10),
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

function convertPgQueryToMysql(text: string): string {
  return text.replace(/\$(\d+)/g, '?');
}

export async function query(text: string, params?: any[]): Promise<{ rows: any[]; rowCount: number }> {
  const mysqlSql = convertPgQueryToMysql(text);
  const [rows] = await pool.query(mysqlSql, params || []);
  const list = Array.isArray(rows) ? (rows as any[]) : [rows];
  return { rows: list, rowCount: list.length };
}

export async function getClient() {
  const connection = await pool.getConnection();
  return {
    query: async (text: string, params?: any[]): Promise<{ rows: any[]; rowCount: number }> => {
      const mysqlSql = convertPgQueryToMysql(text);
      const [rows] = await connection.query(mysqlSql, params || []);
      const list = Array.isArray(rows) ? (rows as any[]) : [rows];
      return { rows: list, rowCount: list.length };
    },
    release: () => connection.release(),
  };
}

export async function initDb() {
  console.log('[DB] Connected to MySQL database.');
}

